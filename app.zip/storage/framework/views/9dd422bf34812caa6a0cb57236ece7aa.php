
<?php $__env->startSection("title","Print Claims"); ?>
<?php $__env->startSection('content'); ?>

<div class="container pb-5 printer">
     <div class="row top-row bg-primary mb-2">
        <p class="text-center text-uppercase text-light fw-bold fs-1">Print Claims</p>
     </div>

     <div class=" bg-light rounded border pt-5 pb-5 pl-10 pr-10">
      <div id="showclaimlist">
       <div class="row grid-container ">

        <div class="col-sm-12">
            <?php if(empty(!$claims)): ?>
            <div class="alert alert-info text-left" role="alert" id="alertmessage2" style="display:block;">
                <span class="fw-bold">Select a claim to remove it from the list or delete. Click <a href="<?php echo e(route('claims.mileage')); ?>">
                    <span class="text-primary fw-bold">here</span></a> to make changes to the claims. </span>
            </div>
            <?php endif; ?>

            <div class="alert alert-success" role="alert" id="alertmessage">
                <span class="message"></span>
                <?php if(empty($claims)): ?>
                <?php else: ?>
                <div class="spinner-border text-success" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <?php endif; ?>
            </div>

            <div class="row mt-3 mb-4">
                <div class="col-sm-6">
                    <h2 class=" text-primary fs-2">
                        <?php if($claims !=null): ?>
                        <?php $totalclaim =0 ?>
                        <?php $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <?php $totalclaim += $claim->claimamount ?>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         Total Claim <span id="totalamounttxt"> <?php echo 'KES. ' . number_format($totalclaim, 2); ?> </span>
                         <?php else: ?>
                         Total Claim KES. 0.00
                         <?php endif; ?>
                    </h2>
                </div>
                <div class="col-sm-2">
                    <button type="button" class="btn btn-sm btn-block btn-primary text-primary" id="printclaimpreviewbtn">
                        <i class="fa fa-eye"></i> Print Preview
                    </button>
                </div>
                <div class="col-sm-2">
                    <button type="button" id="removeclaimbtn" class="btn btn-sm btn-block btn-warning text-warning">
                        <i class="fa fa-xmark"></i> Remove
                    </button>
                </div>
                <div class="col-sm-2">
                    <button type="button" class="btn btn-sm btn-block btn-danger text-danger" id="deleteclaimbtn">
                        <i class="fa fa-trash"></i> Delete
                    </button>
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-sm-12">
                    <div class="table-responsive overflow-hidden">
                        <table class="table table-hover table-bordered table-striped " id="claimprinttable">
                            <?php if(empty($claims)): ?> <!-- if data found -->
                            <?php else: ?>
                             <thead class="thead-dark ">
                                <th style="width: 3%; font-size:13px;" class="align-items-center"> </th>
                                <th style="width: 3%;font-size:13px;">No</th>
                                <th style="width: 8%; font-size:13px;">Ticket#</th>
                                <th style="width: 8%; font-size:13px;">Service Date</th>
                                <th style="width: 6%; font-size:13px;">Time</th>
                                <th style="width: 6%; font-size:12px;">Job Card#</th>
                                <th style="width: 8%; font-size:13px;">Bill Ref#</th>
                                <th style="width: 12%; font-size:13px;">Client</th>
                                <th style="width: 15%; font-size:13px;">Task</th>
                                <th style="width: 10%; font-size:13px;">Site</th>

                                <th style="width: 10%">Amount</th>
                            </thead>
                            <?php endif; ?>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $claims; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$claim): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr id='<?php echo e($claim->ticketno); ?>'>
                                        <td class="text-center">
                                            <input class="form-check-input" type="checkbox" value="" name="flexCheckDefault">
                                        </td>
                                        <td style="text-align: center;"><?php echo e($key+1); ?></td>
                                        <td style=""><?php echo e($claim->ticketno); ?></td>
                                        <td>
                                            <?php if($claim->start_time!=null): ?>
                                                <?php echo e(\Carbon\Carbon::parse($claim->start_time)->format('d M,Y')); ?>

                                            <?php else: ?>
                                                Not updated
                                            <?php endif; ?>
                                        </td>
                                        <td> <?php if($claim->start_time!=null && $claim->end_time!=null ): ?>
                                            <?php echo e(Carbon\Carbon::parse($claim->start_time)->format('H:i')); ?> to
                                            <?php echo e(Carbon\Carbon::parse($claim->end_time)->format('H:i')); ?>

                                          <?php else: ?>
                                             Not updated
                                          <?php endif; ?>
                                        </td>
                                        <td> <?php if($claim->jobcardno!=null): ?>
                                            <?php echo e($claim->jobcardno); ?>

                                            <?php else: ?>
                                              Not updated
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($claim->billingrefno); ?></td>
                                        <td><?php echo e($claim->clientname); ?></td>
                                        <td style="font-size:13px;"><?php echo e($claim->faultreported); ?></td>
                                        <td><?php echo e($claim->city); ?></td>

                                        <td class="text-left"><?php echo 'KES. ' . number_format($claim->claimamount, 2); ?></td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="alert alert-info text-center" role="alert">
                                    No claim found. Click <a href="<?php echo e(route('claims.mileage')); ?>">
                                        <span class="text-primary fw-bold">here</span></a> to update your claims.
                                  </div>
                                <?php endif; ?>
                            </tbody>
                            <tfoot></tfoot>
                        </table>
                        <div class="row pl-10 pr-10 pb-10">
                            <div class="col-sm-12">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


     </div>
     </div>



     </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\serviceclaims\resources\views/mileage/printclaims.blade.php ENDPATH**/ ?>