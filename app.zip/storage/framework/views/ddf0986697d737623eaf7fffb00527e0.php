
<?php $__env->startSection('title','Unauthorised Access'); ?>
<?php $__env->startSection('content'); ?>

<div class="container overflow-hidden">
    <div class="main-body">
        <div class="row gutters-sm justify-content-center">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="display-6 text-danger text-center">Unauthorised Access</h2>
                        <p class="text-center">The page you are trying to access is restricted. Please contact Admin for assistance.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\serviceclaims\resources\views/auth/unauthorised.blade.php ENDPATH**/ ?>