import './bootstrap';
import.meta.glob([ '../images/**', ]);

import Alpine from 'alpinejs';

import { Datepicker } from 'vanillajs-datepicker';

import { jsPDF } from "jspdf";

window.Alpine = Alpine;

Alpine.start();
